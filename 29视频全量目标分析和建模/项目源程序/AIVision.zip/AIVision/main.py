from __future__ import division, print_function, absolute_import
import os
import sys
from timeit import time
import warnings
import cv2
import numpy as np
from PIL import Image
import shutil
import pynvml
import requests
import argparse

from core.yolo import YOLO
from core.deep_sort import preprocessing
from core.deep_sort import nn_matching
from core.deep_sort.detection import Detection
from core.deep_sort.tracker import Tracker
from core.tools import generate_detections as gdet
from collections import deque
from keras import backend

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
APP_STATIC = os.path.join(APP_ROOT)

sys.path.append(os.path.abspath(os.path.dirname(__file__) + '/' + '..'))
sys.path.append("..")

parser = argparse.ArgumentParser()
parser.add_argument('--video_name', default='camera', help='the video name')
args = parser.parse_args()

backend.clear_session()

pynvml.nvmlInit()
handle = pynvml.nvmlDeviceGetHandleByIndex(0)

pts = [deque(maxlen=30) for _ in range(9999)]
warnings.filterwarnings('ignore')

np.random.seed(100)
COLORS = np.random.randint(0, 255, size=(200, 3),dtype="uint8")


def run(yolo, video_path):

    max_cosine_distance = 0.5
    nn_budget = None
    nms_max_overlap = 0.45

    model_filename = 'core/model_data/market1501.pb'
    encoder = gdet.create_box_encoder(os.path.join(APP_STATIC, model_filename),batch_size=1)

    metric = nn_matching.NearestNeighborDistanceMetric("cosine", max_cosine_distance, nn_budget)
    tracker = Tracker(metric)

    countlist = dict()
    scorelist = dict()
    if os.path.exists(os.path.join(APP_STATIC, 'static/output')):
        shutil.rmtree(os.path.join(APP_STATIC, 'static/output'))
    os.makedirs(os.path.join(APP_STATIC, 'static/output'))
    for line in open(os.path.join(APP_STATIC, 'core/obj.txt'), 'r').readlines():
        os.makedirs(os.path.join(APP_STATIC, 'static/output/') + line.strip('\n'))
        label = line.strip('\n')
        countlist[label] = []

    start = time.time()
    capture = cv2.VideoCapture(video_path)

    fps = 0.0
    c = 0
    while True:

        ret, frame = capture.read()
        if ret != True:
            break

        if c % 3 == 0:
            t1 = time.time()
            image = Image.fromarray(frame[...,::-1])
            boxs,class_names = yolo.detect_image(image)
            features = encoder(frame, boxs)
            detections = [Detection(class_name, bbox, 1.0, feature) for class_name, bbox, feature in zip(class_names, boxs, features)]

            boxes = np.array([d.tlwh for d in detections])
            scores = np.array([d.confidence for d in detections])
            indices = preprocessing.non_max_suppression(boxes, nms_max_overlap, scores)
            detections = [detections[i] for i in indices]

            tracker.predict()
            tracker.update(detections)

            indexIDs = []
            countnow = dict()
            image_path = ''
            for line in open(os.path.join(APP_STATIC, 'core/obj.txt'), 'r').readlines():
                label = line.strip('\n')
                countnow[label] = []
            for track in tracker.tracks:
                if not track.is_confirmed() or track.time_since_update > 1:
                    continue
                indexIDs.append(int(track.track_id))
                bbox = track.to_tlbr()
                track_name = track.to_name()
                image = Image.fromarray(frame[..., ::-1])
                if track.track_id in scorelist:
                    if track_name[1] > scorelist[track.track_id]:
                        scorelist[track.track_id] = track_name[1]
                else:
                    scorelist[track.track_id] = track_name[1]

                if os.path.exists(os.path.join(APP_STATIC, 'static/output/') + track_name[0] + '/' + track_name[0] + str(track.track_id) + '.png'):
                    if track_name[1] == scorelist[track.track_id]:
                        image = image.crop((int(bbox[0]), int(bbox[1]), int(bbox[2]), int(bbox[3])))
                        image.save(os.path.join(APP_STATIC, 'static/output/') + track_name[0] + '/' + track_name[0] + str(track.track_id) + '.png')
                    else:
                        pass
                else:
                    image = image.crop((int(bbox[0]), int(bbox[1]), int(bbox[2]), int(bbox[3])))
                    image.save(os.path.join(APP_STATIC, 'static/output/') + track_name[0] + '/' + track_name[0] + str(track.track_id) + '.png')
                    image_path = 'static/output/' + track_name[0] + '/' + track_name[0] + str(track.track_id) + '.png'
                    try:
                        ws = requests.get("http://127.0.0.1:5000/pushimg?msg=%s" % (image_path), timeout=5)
                    except Exception as e:
                        print(e)

                countnow[track_name[0]].append(int(track.track_id))
                countlist[track_name[0]].append(int(track.track_id))
            fps = (fps + (1. / (time.time() - t1))) / 2
            print("FPS = %.3f" % (fps))
            meminfo = pynvml.nvmlDeviceGetMemoryInfo(handle)
            totalmem = meminfo.total / 1024 ** 2
            usedmem = meminfo.used / 1024 ** 2
            runtime = (time.time() - start) / 60
            nownum = []
            totalnum = []
            for key, values in countnow.items():
                nownum.append(len(set(values)))
            for key, values in countlist.items():
                totalnum.append(len(set(values)))
            msg1 = [round(fps, 3),round(totalmem, 3),round(usedmem, 3),round(runtime, 3)]
            msg2 = [nownum, totalnum]
            try:
                ws = requests.get("http://127.0.0.1:5000/push?msg=%s" % (msg1), timeout=5)
                ws = requests.get("http://127.0.0.1:5000/pushthingnum?msg=%s" % (msg2), timeout=5)
            except:
                print('1')

        c = c + 1

    with open(os.path.join(APP_STATIC, 'static/output/result_count.txt'), 'w') as f:
        for key, values in countlist.items():
            f.write(key + ':' + str(len(set(values))) + '\n')

    print("[Finish]")

    capture.release()
    cv2.destroyAllWindows()


#python main.py --video_name=video.mp4
if __name__ == '__main__':
    if args.video_name == 'camera':
        run(YOLO(), 0)
    else:
        run(YOLO(), './static/input/' + args.video_name)
