function valueData(valuelist) {
    var now = new Date();
    Minutes = now.getMinutes();
    Seconds = now.getSeconds();
    if (Minutes < 10){
        Minutes = '0' + Minutes;
    }
    if (Seconds < 10){
        Seconds = '0' + Seconds;
    }
    return {
        name: now.toString(),
        value: [
            [now.getFullYear(), now.getMonth() + 1, now.getDate()].join('-') + ' ' + [now.getHours(), Minutes, Seconds].join(':'), valuelist
        ]
    };
}

var data = [];
for (var i = 0; i < 100; i++) {
    data.push([]);
}

option1 = {
    tooltip: {//鼠标指上时的标线
        trigger: 'axis',
        axisPointer: {
            lineStyle: {
                color: '#fff'
            }
        }
    },
    legend: {
        icon: 'rect',
        itemWidth: 14,
        itemHeight: 5,
        itemGap: 13,
        right: '10px',
        top: '0px',
        textStyle: {
            fontSize: 12,
            color: '#fff'
        }
    },
    grid: {
        x: 35,
        y: 25,
        x2: 8,
        y2: 25,
    },
    xAxis: [{
        type: 'time',
        splitLine: {
            show: false
        },
        boundaryGap: false,
        axisLine: {
            lineStyle: {
                color: '#57617B'
            }
        },
        axisLabel: {
            textStyle: {
                color:'#fff',
            },
        },
    }],
    yAxis: [{
        type: 'value',
        boundaryGap: [0, '100%'],
        axisTick: {
            show: false
        },
        axisLine: {
            lineStyle: {
                color: '#57617B',
            }
        },
        axisLabel: {
            margin: 10,
            textStyle: {
                fontSize: 14
            },
            textStyle: {
                color:'#fff',
            },
        },
        splitLine: {
            lineStyle: {
                color: 'rgba(255,255,255,.2)',
				type:'dotted',
            }
        }
    }],
    series: [{
        type: 'line',
        smooth: true,
        showSymbol: false,
        hoverAnimation: false,
        lineStyle: {
            normal: {
                width: 2
            }
        },
        areaStyle: {
            normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                    offset: 0,
                    color: 'rgba(137, 189, 27, 0.3)'
                }, {
                    offset: 0.8,
                    color: 'rgba(137, 189, 27, 0)'
                }], false),
                shadowColor: 'rgba(0, 0, 0, 0.1)',
                shadowBlur: 10
            }
        },
        itemStyle: {
            normal: {
                color: 'rgb(137,189,27)'
            }
        },
        data: data
    }]
};

var data1 = [];
for (var i = 0; i < 30; i++) {
    data1.push([]);
}
var data2 = [];
for (var i = 0; i < 30; i++) {
    data2.push([]);
}
var data3 = [];
for (var i = 0; i < 30; i++) {
    data3.push([]);
}

option2 = {
    tooltip: {//鼠标指上时的标线
        trigger: 'axis',
        axisPointer: {
            lineStyle: {
                color: '#fff'
            }
        }
    },
    legend: {
        icon: 'rect',
        itemWidth: 14,
        itemHeight: 5,
        itemGap: 13,
        data: ['行人', '汽车', '公交'],
        right: '10px',
        top: '0px',
        textStyle: {
            fontSize: 12,
            color: '#fff'
        }
    },
    grid: {
        x: 35,
        y: 25,
        x2: 8,
        y2: 25,
    },
    xAxis: [{
        type: 'time',
        splitLine: {
            show: false
        },
        boundaryGap: false,
        axisLine: {
            lineStyle: {
                color: '#57617B'
            }
        },
        axisLabel: {
            textStyle: {
                color:'#fff',
            },
        },
    }],
    yAxis: [{
        type: 'value',
        boundaryGap: [0, '100%'],
        axisTick: {
            show: false
        },
        axisLine: {
            lineStyle: {
                color: '#57617B',
            }
        },
        axisLabel: {
            margin: 10,
            textStyle: {
                fontSize: 14
            },
            textStyle: {
                color:'#fff',
            },
        },
        splitLine: {
            lineStyle: {
                color: 'rgba(255,255,255,.2)',
				type:'dotted',
            }
        }
    }],
    series: [{
        name: '行人',
        type: 'line',
        smooth: true,
        lineStyle: {
            normal: {
                width: 2
            }
        },
        areaStyle: {
            normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                    offset: 0,
                    color: 'rgba(137, 189, 27, 0.3)'
                }, {
                    offset: 0.8,
                    color: 'rgba(137, 189, 27, 0)'
                }], false),
                shadowColor: 'rgba(0, 0, 0, 0.1)',
                shadowBlur: 10
            }
        },
        itemStyle: {
            normal: {
                color: 'rgb(137,189,27)'
            }
        },
        data: data1
    }, {
        name: '汽车',
        type: 'line',
        smooth: true,
        lineStyle: {
            normal: {
                width: 2
            }
        },
        areaStyle: {
            normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                    offset: 0,
                    color: 'rgba(0, 136, 212, 0.3)'
                }, {
                    offset: 0.8,
                    color: 'rgba(0, 136, 212, 0)'
                }], false),
                shadowColor: 'rgba(0, 0, 0, 0.1)',
                shadowBlur: 10
            }
        },
        itemStyle: {
            normal: {
                color: 'rgb(0,136,212)'
            }
        },
        data: data2
    }, {
        name: '公交',
        type: 'line',
        smooth: true,
        lineStyle: {
            normal: {
                width: 2
            }
        },
        areaStyle: {
            normal: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                    offset: 0,
                    color: 'rgba(219, 50, 51, 0.3)'
                }, {
                    offset: 0.8,
                    color: 'rgba(219, 50, 51, 0)'
                }], false),
                shadowColor: 'rgba(0, 0, 0, 0.1)',
                shadowBlur: 10
            }
        },
        itemStyle: {
            normal: {
                color: 'rgb(219,50,51)'
            }
        },
        data: data3
    }]
};

function  Video(videopath){
    var video = document.getElementById('video');
    video.src = videopath;
}

function  Camera(){
    function getUserMedia(constraints, success, error) {
        if (navigator.mediaDevices.getUserMedia) {
            //最新的标准API
            navigator.mediaDevices.getUserMedia(constraints).then(success).catch(error);
        } else if (navigator.webkitGetUserMedia) {
            //webkit核心浏览器
            navigator.webkitGetUserMedia(constraints, success, error)
        } else if (navigator.mozGetUserMedia) {
            //firfox浏览器
            navigator.mozGetUserMedia(constraints, success, error);
        } else if (navigator.getUserMedia) {
            //旧版API
            navigator.getUserMedia(constraints, success, error);
        }
    }
    var video = document.getElementById('video');

    function success(stream) {
        //兼容webkit核心浏览器
        let CompatibleURL = window.URL || window.webkitURL;
        //将视频流设置为video元素的源
        console.log(stream);
        video.srcObject = stream;
        video.play();
    }

    function error(error) {
        console.log(`访问用户媒体设备失败${error.name}, ${error.message}`);
    }

    if (navigator.mediaDevices.getUserMedia || navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia) {
        //调用用户媒体设备, 访问摄像头
        getUserMedia({video: {width: 700, height: 500}}, success, error);
    } else {
        alert('不支持访问用户媒体');
    }
}

function addpersonimg(text) {
    var carresult = document.getElementById('personresult');
    var li = document.createElement("li");
    li.innerHTML = text;
    carresult.insertBefore(li, carresult.childNodes[0]);
    carresult.removeChild(carresult.childNodes[20]);
}

function addcarimg(text) {
    var carresult = document.getElementById('carresult');
    var li = document.createElement("li");
    li.innerHTML = text;
    carresult.insertBefore(li, carresult.childNodes[0]);
    carresult.removeChild(carresult.childNodes[20]);
}

function addbusimg(text) {
    var carresult = document.getElementById('busresult');
    var li = document.createElement("li");
    li.innerHTML = text;
    carresult.insertBefore(li, carresult.childNodes[0]);
    carresult.removeChild(carresult.childNodes[20]);
}
