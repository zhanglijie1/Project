import sys
import os
from flask import Flask, request, render_template
from flask_socketio import SocketIO, emit
import subprocess
from multiprocessing import Process


sys.path.append(os.path.abspath(os.path.dirname(__file__) + '/' + '..'))
sys.path.append("..")

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)
name_space = '/test'
client_query = []


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/push')
def push_once():
    data = request.args.get("msg")
    broadcasted_data = {'data': data}
    emit('fps response', broadcasted_data, broadcast=True, namespace=name_space)
    return 'send msg ok!'


@app.route('/pushthingnum')
def push_totalnum():
    data = request.args.get("msg")
    broadcasted_data = {'data': data}
    emit('number response', broadcasted_data, broadcast=True, namespace=name_space)
    return 'send msg ok!'


@app.route('/pushimg')
def push_image():
    data = request.args.get("msg")
    broadcasted_data = {'data': data}
    emit('iamge response', broadcasted_data, broadcast=True, namespace=name_space)
    return 'send msg ok!'


@socketio.on('connect', namespace=name_space)
def test_connect():
    # 建立连接 sid:连接对象ID
    client_id = request.sid
    print('1 connected ==> ', client_id)
    client_query.append(client_id)
    emit('connect', '%s connect successful!' % client_id, broadcast=True)


@socketio.on('disconnect', namespace=name_space)
def test_disconnect():
    # 连接对象关闭 删除对象ID
    client_query.remove(request.sid)
    print('0 Client disconnected==> ', request.sid)


if __name__ == '__main__':
    socketio.run(app, debug=True)